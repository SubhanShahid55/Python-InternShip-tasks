import os
import tkinter as tk
from tkinter import filedialog
from tkinter import ttk
from pygame import mixer

root=tk.Tk()
root.title("PYTHON AUDIO PLAYER")
root.geometry("500x300")
mixer.init()

def play_audio():
    file_path = filedialog.askopenfilename()
    mixer.music.load(file_path)
    mixer.music.play()
    print(f"Playing audio from: {file_path}")

def stop_audio():
    mixer.music.stop()
    print("Audio stopped")
    
def pause_audio():
    if mixer.music.get_busy():
        mixer.music.pause()
        print("Audio paused")
    else:
        print("No audio to pause")
    
def resume_audio():
    if not mixer.music.get_busy():
        mixer.music.unpause()
        print("Audio resumed")
    else:
        print("No audio to resume")

def load_song():
    global song_path
    song_path = filedialog.askopenfilename(title="Select a Song", filetypes=[("MP3 Files", "*.mp3")])
    song_label.config(text=os.path.basename(song_path))

song_label = tk.Label(root, text="No Song Selected", font=("Arial", 12))

play_button = tk.Button(root, text="Play", font=("Arial", 12), command=play_audio)


load_button = tk.Button(root, text="Load Song", command=load_song)
load_button.pack(pady=5)


resume_button = tk.Button(root, text="Resume", command=resume_audio)
resume_button.pack(pady=5)


stop_button = tk.Button(root, text="Stop", command=stop_audio)
stop_button.pack(pady=5)

progress_bar = ttk.Progressbar(root, orient="horizontal", length=400, mode="determinate")
progress_bar.pack(pady=20)


root.mainloop()

