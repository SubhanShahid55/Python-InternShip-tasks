# Program of simple calculator that perform basic Arithmetic operation in ClI mode

a=input("Enter 1st number:")
b=input("Enter 2nd number:")
print("\nEnter your choice.....")
print("\n0.Exit")
print("\n1.Add")
print("\n2.Multiply")
print("\n3.Subtract")
print("\n4.Divide")
print("\n5.Square")
choice=input("Enter your choice: ")

if choice=="1":
    result=int(a)+int(b)
    print("\nThe result is:",result)
elif choice=="2":
    result=int(a)*int(b)
    print("\nThe result is:",result)

elif choice=="3":
    result=int(a)-int(b)
    print("\nThe result is:",result)

elif choice=="4":
    result=int(a)/int(b)
    print("\nThe result is:",result)
    
elif choice=="5":
    print("\nEnter a number: ")
    z=input()
    result=int(z)**2
    print("\nThe result is:",result)
    
elif choice=="0":
    print("\nExiting...")
    
else:
    print("\nInvalid choice. Please try again.")
    exit()
    

